class Parent{
    final void show();
}
class Child extends Parent
{
    void show()
    {}
}
// this is not possible because a final method cannot be extended